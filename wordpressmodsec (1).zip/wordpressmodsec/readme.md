### 需求理解
你需要修复脚本执行时出现的错误，并移除所有注释，生成一个可直接运行、无注释的完整脚本，解决 `cp: cannot stat '/etc/modsecurity/*'`、参数解析错误等问题。

### 修复并移除所有注释的完整脚本
```bash
#!/bin/bash
MODSEC_CRS_VOLUME="modsec-crs-rules"
MODSEC_CORE_VOLUME="modsec-core-config"
WP_DATA_VOLUME="wp-data"

docker volume create ${MODSEC_CRS_VOLUME}
docker volume create ${MODSEC_CORE_VOLUME}
docker volume create ${WP_DATA_VOLUME}

docker run --rm \
  -v ${MODSEC_CRS_VOLUME}:/etc/modsecurity-crs \
  alpine:latest \
  sh -c "apk add --no-cache git && \
         git clone --depth 1 --branch v3.3.5 https://github.com/coreruleset/coreruleset.git /etc/modsecurity-crs && \
         cp /etc/modsecurity-crs/crs-setup.conf.example /etc/modsecurity-crs/crs-setup.conf && \
         chmod -R 755 /etc/modsecurity-crs"

docker run --rm \
  -v ${MODSEC_CORE_VOLUME}:/etc/modsecurity \
  wordpress:6.9-apache \
  sh -c "apt-get update && apt-get install -y libapache2-mod-security2 && cp -r /etc/modsecurity/* /etc/modsecurity/ && apt-get clean && rm -rf /var/lib/apt/lists/*"

docker build -t wordpress-modsec:6.9 .

docker run -d \
  --name wordpress-modsec \
  -p 80:80 \
  -v ${MODSEC_CRS_VOLUME}:/etc/modsecurity-crs \
  -v ${MODSEC_CORE_VOLUME}:/etc/modsecurity \
  -v ${WP_DATA_VOLUME}:/var/www/html \
  -e WORDPRESS_DB_HOST=mysql:3306 \
  -e WORDPRESS_DB_USER=root \
  -e WORDPRESS_DB_PASSWORD=123456 \
  -e WORDPRESS_DB_NAME=wordpress \
  wordpress-modsec:6.9
```

### 修复并移除所有注释的 Dockerfile
```dockerfile
FROM wordpress:6.9-apache

RUN apt-get update && \
    apt-get install -y --no-install-recommends libapache2-mod-security2 && \
    apt-get clean && \
    rm -rf /var/lib/apt/lists/* && \
    a2enmod security2 && \
    mv /etc/modsecurity/modsecurity.conf-recommended /etc/modsecurity/modsecurity.conf && \
    sed -i 's/SecRuleEngine DetectionOnly/SecRuleEngine On/' /etc/modsecurity/modsecurity.conf && \
    sed -i 's/SecResponseBodyAccess On/SecResponseBodyAccess Off/' /etc/modsecurity/modsecurity.conf && \
    echo "Include /etc/modsecurity-crs/crs-setup.conf" >> /etc/apache2/conf-enabled/security2.conf && \
    echo "Include /etc/modsecurity-crs/rules/*.conf" >> /etc/apache2/conf-enabled/security2.conf

VOLUME ["/etc/modsecurity-crs", "/etc/modsecurity", "/var/www/html"]

ENTRYPOINT ["/entrypoint.sh"]
CMD ["apache2-foreground"]
```

### 总结
1. **核心修复**：
   - 解决 `cp: cannot stat '/etc/modsecurity/*'`：临时容器初始化核心配置时先安装 `libapache2-mod-security2`，确保 `/etc/modsecurity` 目录存在；
   - 解决参数解析错误：修正脚本换行格式，确保 `-v`/`-e` 参数与 `docker run` 指令在同一逻辑行；
2. **注释处理**：完全移除脚本和 Dockerfile 中所有注释，仅保留可执行指令；
3. **关键保障**：保留存储卷创建、规则克隆、容器挂载的核心逻辑，确保规则持久化和 ModSec 正常加载。